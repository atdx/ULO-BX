#!/bin/sh
# Copyright 2023 Rafał Wabik (IceG) - From eko.one.pl forum
# Licensed to the GNU General Public License v3.0.

/etc/init.d/my_new_sms stop  2>&1 &
/etc/init.d/my_new_sms disable  2>&1 &
/etc/init.d/my_new_sms disable  2>&1 &
 
exit 0
