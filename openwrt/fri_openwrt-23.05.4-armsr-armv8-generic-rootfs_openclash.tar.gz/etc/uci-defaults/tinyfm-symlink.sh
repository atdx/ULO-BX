#!/bin/sh

cd /
[ ! -d /www/tinyfm/rootfs ] && ln -s / /www/tinyfm/rootfs
exit 0
